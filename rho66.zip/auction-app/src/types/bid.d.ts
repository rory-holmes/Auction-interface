type Bid = {
    bidderId: number,
    firstName: string,
    lastName: string,
    timestamp: string,
    amount: number,
}